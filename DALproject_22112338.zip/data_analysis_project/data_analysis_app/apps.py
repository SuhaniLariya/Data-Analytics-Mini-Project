from django.apps import AppConfig


class DataAnalysisAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'data_analysis_app'
