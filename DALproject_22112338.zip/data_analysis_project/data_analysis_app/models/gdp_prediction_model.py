import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pickle

# Load the data from the CSV file
data = pd.read_csv('C:/Users/geete/OneDrive/Desktop/sem3/Data Analytics/finaldata.csv')

# Select features (independent variables) and the target variable
features = data[['Inflation', 'FDI', 'Exchange rate', 'Population', 'Money Supply']]
target = data['GDP']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Create and train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model on the test set
accuracy = model.score(X_test, y_test)
print(f'Model Accuracy: {accuracy * 100:.2f}%')

# Save the model using pickle
with open('gdp_prediction_model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)
